<?php
include "db_con.php";
$id=$_GET["id"];

$firstname="";
$lastname="";
$contact="";
$email="";
$position="";


$res=mysqli_query($link,"select * from boardm where id=$id");
while($row=mysqli_fetch_array($res))
{
	$firstname=$row["firstname"];
	$lastname=$row["lastname"];
	$email=$row["email"];
	$contact=$row["contact"];
	$email=$row["email"];
	$position=$row["position"];
	
}

?>

<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
<div class="col-lg-4">
  <h2>POWA Board Members</h2>
  <form action="" name="form1" method="post">
    <div class="form-group">
      <label for="email">First Name:</label>
      <input type="text" class="form-control" id="firstname" placeholder="Enter fristname" name="firstname" value="<?php echo $firstname;?>">
    </div>
    <div class="form-group">
      <label for="pwd">Last Name:</label>
      <input type="text" class="form-control" id="lastname" placeholder="Enter lastname" name="lastname" value="<?php echo $lastname;?>">
    </div>
	 <div class="form-group">
      <label for="pwd">Contact:</label>
      <input type="text" class="form-control" id="contact" placeholder="Enter contact" name="contact" value="<?php echo $contact;?>">
    </div>
	<div class="form-group">
      <label for="pwd">email:</label>
      <input type="text" class="form-control" id="email" placeholder="Enter email" name="email" value="<?php echo $email;?>">
    </div>
	 <div class="form-group">
      <label for="pwd">Position:</label>
      <input type="text" class="form-control" id="position" placeholder="Enter position" name="position" value="<?php echo $position;?>">
    </div>
    
    
	<button type="submit" name="update" class="btn btn-default">Update</button>
	
  </form>
</div>
</div>

<div class="col-lg-12">



</div>


</body>
<?php
if (isset ($_POST["update"]))
	{
		
		mysqli_query($link,"update boardm set firstname='$_POST[firstname]',lastname='$_POST[lastname]',contact='$_POST[contact]',email='$_POST[email]',position='$_POST[position]' where id=$id");
		?>
		<script type="text/javascript">
		window.location="boardm.php";
		</script>
		<?php
	}
?>



</html>
