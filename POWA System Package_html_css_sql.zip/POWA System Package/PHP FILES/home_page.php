<?php 
  session_start(); 

  if (!isset($_SESSION['username'])) {
  	$_SESSION['msg'] = "You must log in first";
  	header('location: login.php');
  }
  if (isset($_GET['logout'])) {
  	session_destroy();
  	unset($_SESSION['username']);
  	header("location: login.php");
  }
?>
<!DOCTYPE html>
<html>
<head>
	<title>powa management system</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<link rel="stylesheet" type="text/css" href="style1.css">
		
</head>
<body>
	<div class="topnav">
	  <a class="active" href="#home">Home</a>
	  <a href="women.php">Women</a>
	  <a href="social_worker.php">Social Workers</a>
	  <a href="staff.php">Staff</a>
	  <a href="branches.php">Branches</a>
	  <a href="boardm.php">Board Members</a>
	  <a href="donors.php">Donors</a>
	  <a href="volunteers.php">Volunteers</a>
	  <a href="partners.php">Partners</a>
	  <a href="projects.php">Projects</a>
	   

	</div>
	<img src="Powa-Logo.png" style="max-width:10%;height:auto;" align="left"> 
			<div class="content">
				<!-- notification message -->
				<?php if (isset($_SESSION['success'])) : ?>
				  <div class="error success" >
					<h3>
					  <?php 
						echo $_SESSION['success']; 
						unset($_SESSION['success']);
					  ?>
					</h3>
				  </div>
				<?php endif ?>

				<!-- logged in user information -->
				<?php  if (isset($_SESSION['username'])) : ?>
					<center><h1>Welcome <strong><?php echo $_SESSION['username']; ?></strong></h1></center>
					<h3> <a href="index.php?logout='1'" style="color: red;">logout</a> </h3>
				<?php endif ?>
			</div>

	<center><img src="powavision.png" style="max-width:100%;height:auto;"></center>

			
	
</body>

</html>
