<?php
$link=mysqli_connect("localhost","root","Marweshe@699") or die(mysql_error($link));
mysqli_select_db($link,"powa_db") or die(mysql_error($link));

?>