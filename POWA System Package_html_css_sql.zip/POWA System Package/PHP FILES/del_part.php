<?php
include "db_con.php";
$id=$_GET["id"];
mysqli_query($link,"delete from partners where id=$id");
?>

<script type="text/javascript">
window.location="partners.php";

</script>