<?php
include "db_con.php";
$id=$_GET["id"];
mysqli_query($link,"delete from volunteers where id=$id");
?>

<script type="text/javascript">
window.location="volunteers.php";

</script>