<?php
include "db_con.php";
$id=$_GET["id"];

$name="";
$address="";
$contact="";
$contact_person="";
$email="";


$res=mysqli_query($link,"select * from donors where id=$id");
while($row=mysqli_fetch_array($res))
{
	$name=$row["name"];
	$address=$row["address"];
	$email=$row["email"];
	$contact=$row["contact"];
	$address=$row["contact_person"];
	
	
}

?>

<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
<div class="col-lg-4">
  <h2>POWA Donors</h2>
  <form action="" name="form1" method="post">
    <div class="form-group">
      <label for="name">Name:</label>
      <input type="text" class="form-control" id="name" placeholder="Enter name" name="name" value="<?php echo $name;?>">
    </div>
    <div class="form-group">
      <label for="pwd">Address:</label>
      <input type="text" class="form-control" id="address" placeholder="Enter address" name="address" value="<?php echo $address;?>">
    </div>
	 <div class="form-group">
      <label for="pwd">Contact:</label>
      <input type="text" class="form-control" id="contact" placeholder="Enter contact" name="contact" value="<?php echo $contact;?>">
    </div>
	<div class="form-group">
      <label for="pwd">Contact Person:</label>
      <input type="text" class="form-control" id="contact_person" placeholder="Enter contact_person" name="contact_person" value="<?php echo $contact_person;?>">
    </div>

    
    
	<button type="submit" name="update" class="btn btn-default">Update</button>
	
  </form>
</div>
</div>

<div class="col-lg-12">



</div>


</body>
<?php
if (isset ($_POST["update"]))
	{
		
		mysqli_query($link,"update donors set name='$_POST[name]',address='$_POST[address]',contact='$_POST[contact]',contact_person='$_POST[contact_person]' where id=$id");
		?>
		<script type="text/javascript">
		window.location="donors.php";
		</script>
		<?php
	}
?>



</html>
