<?php
include "db_con.php";
$id=$_GET["id"];

$firstname="";
$lastname="";
$contact="";



$res=mysqli_query($link,"select * from socialworkers where id=$id");
while($row=mysqli_fetch_array($res))
{
	$firstname=$row["firstname"];
	$lastname=$row["lastname"];
	$contact=$row["contact"];
	
}

?>

<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
<div class="col-lg-4">
  <h2>POWA Social Workers</h2>
  <form action="" name="form1" method="post">
    <div class="form-group">
      <label for="email">First Name:</label>
      <input type="text" class="form-control" id="firstname" placeholder="Enter fristname" name="firstname" value="<?php echo $firstname;?>">
    </div>
    <div class="form-group">
      <label for="pwd">Last Name:</label>
      <input type="text" class="form-control" id="lastname" placeholder="Enter lastname" name="lastname" value="<?php echo $lastname;?>">
    </div>
	 <div class="form-group">
      <label for="pwd">Contact:</label>
      <input type="text" class="form-control" id="contact" placeholder="Enter contact" name="contact" value="<?php echo $contact;?>">
    </div>

    
    
	<button type="submit" name="update" class="btn btn-default">Update</button>
	
  </form>
</div>
</div>

<div class="col-lg-12">



</div>


</body>
<?php
if (isset ($_POST["update"]))
	{
		
		mysqli_query($link,"update socialworkers set firstname='$_POST[firstname]',lastname='$_POST[lastname]',contact='$_POST[contact]' where id=$id");
		?>
		<script type="text/javascript">
		window.location="social_worker.php";
		</script>
		<?php
	}
?>



</html>
