<?php
include "db_con.php";
$id=$_GET["id"];

$name="";
$description="";
$p_type="";



$res=mysqli_query($link,"select * from projects where id=$id");
while($row=mysqli_fetch_array($res))
{
	$name=$row["name"];
	$description=$row["description"];
	$p_type=$row["p_type"];
	
}

?>

<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
<div class="col-lg-4">
  <h2>POWA Projects</h2>
  <form action="" name="form1" method="post">
    <div class="form-group">
      <label for="type">Name:</label>
      <input type="text" class="form-control" id="name" placeholder="Enter fristname" name="name" value="<?php echo $name;?>">
    </div>
    <div class="form-group">
      <label for="pwd">Description:</label>
      <input type="text" class="form-control" id="description" placeholder="Enter description" name="description" value="<?php echo $description;?>">
    </div>
	 <div class="form-group">
      <label for="pwd">Project Type:</label>
      <input type="text" class="form-control" id="p_type" placeholder="Enter p_type" name="p_type" value="<?php echo $p_type;?>">
    </div>
    
    
	<button type="submit" name="update" class="btn btn-default">Update</button>
	
  </form>
</div>
</div>

<div class="col-lg-12">



</div>


</body>
<?php
if (isset ($_POST["update"]))
	{
		
		mysqli_query($link,"update projects set name='$_POST[name]',description='$_POST[description]',p_type='$_POST[p_type]' where id=$id");
		?>
		<script type="text/javascript">
		window.location="projects.php";
		</script>
		<?php
	}
?>



</html>
