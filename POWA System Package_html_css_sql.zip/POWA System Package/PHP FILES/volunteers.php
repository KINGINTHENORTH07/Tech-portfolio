<?php
include "db_con.php";

?>

<html lang="en">
<head>
	<title>powa management system</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
		
</head>
<body>
	
		<div class="topnav">
	  <a href="home_page.php">Home</a>
	  <a href="women.php">Women</a>
	  <a href="social_worker.php">Social Workers</a>
	  <a href="staff.php">Staff</a>
	  <a href="branches.php">Branches</a>
	  <a href="boardm.php">Board Members</a>
	  <a href="donors.php">Donors</a>
	  <a class="active" href="volunteers.php">Volunteers</a>
	  <a href="partners.php">Partners</a>
	  <a href="projects.php">Projects</a>
	</div>
<div class="container">
<div class="col-lg-4">
  <h2>Powa Volunteers</h2>
  <form action="" name="form1" method="post">
    <div class="form-group">
      <label for="email">First Name:</label>
      <input type="text" class="form-control" id="firstname" placeholder="Enter fristname" name="firstname">
    </div>
    <div class="form-group">
      <label for="pwd">Last Name:</label>
      <input type="text" class="form-control" id="lastname" placeholder="Enter lastname" name="lastname" >
    </div>
	 <div class="form-group">
      <label for="pwd">Contact:</label>
      <input type="text" class="form-control" id="contact" placeholder="Enter contact" name="contact">
    </div>
	<div class="form-group">
      <label for="pwd">Address:</label>
      <input type="text" class="form-control" id="address" placeholder="Enter address" name="address">
    </div>
	 <div class="form-group">
      <label for="pwd">Volunteer type:</label>
      <input type="text" class="form-control" id="age" placeholder="Enter v_type" name="v_type">
    </div>
    
    <button type="submit" name="insert" class="btn btn-default">Insert</button>
	<button type="submit" name="update" class="btn btn-default">Update</button>
	<button type="submit" name="delete" class="btn btn-default">Delete</button>
  </form>
</div>
</div>

<div class="col-lg-12">

<table class="table table-striped">
    <thead>
      <tr>
		<th>#</th>
        <th>Firstname</th>
        <th>Lastname</th>
		<th>Contact</th>
		<th>Address</th>
		<th>Volunteer type</th>
		<th>Edit</th>
		<th>Delete</th>
      </tr>
    </thead>
    <tbody>
	<?php
		$res=mysqli_query($link,"select * from volunteers");
		while($row=mysqli_fetch_array($res))
		{
			echo "<tr>";
			echo "<td>"; echo $row["id"]; echo"</td>";
			echo "<td>"; echo $row["firstname"]; echo"</td>";
			echo "<td>"; echo $row["lastname"]; echo"</td>";
			echo "<td>"; echo $row["contact"]; echo"</td>";
			echo "<td>"; echo $row["address"]; echo"</td>";
			echo "<td>"; echo $row["v_type"]; echo"</td>";
			echo "<td>";?> <a href="edit_volu.php?id=<?php echo $row["id"];?>"><button type="button" class="btn btn-success">Edit</button></a> <?php echo"</td>";
			echo "<td>";?> <a href="del_volu.php?id=<?php echo $row["id"];?>"><button type="button" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this entry')">Delete</button></a> <?php echo"</td>";
			
			echo "</tr>";
		}
	
	?>
      
	  
    </tbody>
  </table>


</div>


</body>

<?php
if (isset ($_POST["insert"]))
	{
		
		mysqli_query($link,"insert into volunteers values(NULL,'$_POST[firstname]','$_POST[lastname]','$_POST[contact]','$_POST[address]','$_POST[v_type]')");
		?>
		<script type="text/javascript">
		window.location.href=window.location.href;
		</script>
		<?php
	}

if(isset($_POST["delete"]))
{

	mysqli_query($link,"delete from volunteers where firstname='$_POST[firstname]'") or die(mysqli_error($link));
	?>
		<script type="text/javascript">
		window.location.href=window.location.href;
		</script>
		<?php
}
if(isset($_POST["update"]))
{

	mysqli_query($link,"update volunteers set firstname='$_POST[lastname]' where firstname='$_POST[firstname]'") or die(mysqli_error($link));
	?>
		<script type="text/javascript">
		window.location.href=window.location.href;
		</script>
		<?php
}

?>
</html>