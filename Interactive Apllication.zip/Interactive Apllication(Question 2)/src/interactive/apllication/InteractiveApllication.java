/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package interactive.apllication;
import javax.swing.JOptionPane; // program uses JOptionPane class
/**
 *
 * @author TREMAINE
 */
public class InteractiveApllication {

    /**
     * @param args the command line arguments

*/
    public static void main(String[] args) {
        String firstStudentName;
        String firstSchoolHouseAssignment;
        String secondSchoolHouseAssignment;
        String thirdSchoolHouseAssignment;
        String  firstStudentNumber;
        String  secondStudentNumber;
        String thirdStudentNumber;
        String secondStudentName;
        String thirdStudentName;
        String full_studentDetails;
        String full_secondStudentDetails;
        String full_thirdStudentDetails;
        // for strings
        firstStudentName=JOptionPane.showInputDialog("enter the name"); // prompt the user to enter the name;
        firstSchoolHouseAssignment=JOptionPane.showInputDialog("Please enter house assigned to:)"); // prompt the user to enter the house assigned;
        firstStudentNumber=JOptionPane.showInputDialog("please enter student number"); // prompt the user to enter the student number;
        
        
        // second student full details
        secondStudentName=JOptionPane.showInputDialog("enter the name"); // prompt
        secondSchoolHouseAssignment=JOptionPane.showInputDialog("Please enter house assigned to:)"); // prompt
        secondStudentNumber=JOptionPane.showInputDialog("please enter student number"); // prompt
        
       
                // Third Student full details
        thirdStudentName=JOptionPane.showInputDialog("enter the name"); // prompt
        thirdSchoolHouseAssignment=JOptionPane.showInputDialog("Please enter house assigned to:)"); //prompt
        thirdStudentNumber=JOptionPane.showInputDialog("please enter student number"); //prompt
        
        JOptionPane.showMessageDialog(null," Student name " + firstStudentName + " House Assigned " + firstSchoolHouseAssignment + "Student number " + firstStudentNumber + "\n" + " Student name "   +  secondStudentName + " House Assigned " + secondSchoolHouseAssignment + "Student number " + secondStudentNumber + "\n"+ " Student name " + thirdStudentName + " House Assigned" + thirdSchoolHouseAssignment + " Student number "  + thirdStudentNumber ); // display all student results
        
        // TODO code application logic here
    } // end main method
   } // end class
