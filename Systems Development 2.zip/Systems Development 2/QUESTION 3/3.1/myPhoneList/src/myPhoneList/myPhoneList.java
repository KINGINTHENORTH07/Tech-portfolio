/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myPhoneList;
import java.io.FileWriter;   // Import the FileWriter class
import java.io.IOException;  // Import the IOException class to handle errors
import java.io.IOException;  // Import the IOException class to handle errors
import java.util.Scanner;
import javax.swing.JOptionPane;
import java.io.File;  // Import the File class
import java.io.IOException;  // Import the IOException class to handle errors


/**
 *
 * @author User
 */
public class myPhoneList {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        
        //Declarations
        String firstName;
        String lastName;
        int contactNumber;
        
        Scanner inputDevices = new Scanner(System.in); // Create a Scanner object
        System.out.print("Please enter your first name>>");// Prompt the user to enter their first name
        firstName =inputDevices.nextLine();
        System.out.print("Please enter your last name>>"); // Prompt the user to enter their last name
        lastName =inputDevices.nextLine();
        System.out.print("Please enter your contact number>>"); // Prompt the user to enter their contact umber
        contactNumber = inputDevices.nextInt(); //This statement gets the contact number which it's an interger
        System.out.println("First Name: " + firstName + "\nLast Name:" + lastName +
        "\nContact Number:" + contactNumber);  // Output user inputs
        
         try {
      File myObj = new File("myPhoneList.txt"); // creating a file
      if (myObj.createNewFile()) {
        System.out.println("File created: " + myObj.getName());
      } else {
        System.out.println("File already exists."); //output if the file name already exists
      }
    } catch (IOException e) {
      System.out.println("An error occurred.");
      e.printStackTrace();
    }
        
       try {
      FileWriter myWriter = new FileWriter("myPhoneList.txt"); //writting information the file
      myWriter.write("First Name: " + firstName + "\nLast Name:" + lastName +
        "\nContact Number:" + contactNumber);
      myWriter.close();
      System.out.println("Successfully wrote to the file."); //output whe files are successfully written to a file
    } catch (IOException e) {
      System.out.println("An error occurred.");
      e.printStackTrace();
    }
  }
    }
    

