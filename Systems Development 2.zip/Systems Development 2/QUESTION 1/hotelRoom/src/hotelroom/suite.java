/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hotelroom;

/**
 *
 * @author User
 */
public class suite extends HotelRoom {
    
    private double surcharge;
    


public double getSurcharge(){
    
    return surcharge;
    
}

public void setSurcharge()
{
    
    }
    
    
}