/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hotelroom;
import java.util.Scanner;
import javax.swing.JOptionPane;
/**
 *
 * @author User
 */
public class useHotelRoom {
    


    public static void main(String[] arg) {
        
        int roomNumber;
        double rentalRate= 1116.83;;
        double surcharge =638.00;
        double price = 1116.83;
        double rentalRat = 1436.14;
        double totSurcharge = surcharge + rentalRate;
        double totSurcharg = surcharge + rentalRate;
        
        
      HotelRoom hotel = new HotelRoom();
      suite su = new suite();
      
     roomNumber = Integer.parseInt(JOptionPane.showInputDialog("Room Number:")); 
  
     
    if (roomNumber <= 299) {
    JOptionPane.showMessageDialog(null,"Your room Number: " + roomNumber+ "\nRental Price:" + "R"+rentalRate +
            "\nTax: R"+ surcharge + "\nTotal(Inc VAT):" + "\t"+ "R" + totSurcharge);
    
}
 else {
 
JOptionPane.showMessageDialog(null,"Your room Number: " + roomNumber+ "\nRental Price:" + "R"+rentalRat +
        "\nTax: R"+ surcharge + "\nTotal(Inc VAT):" +"\t"+ "R" + totSurcharge);
}    
}
}