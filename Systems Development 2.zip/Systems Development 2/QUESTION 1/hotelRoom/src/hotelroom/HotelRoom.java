/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hotelroom;
import javax.swing.JOptionPane;
/**
 *
 * @author User
 */
public class HotelRoom {
    
    private int roomNumber;
    private double rentalRate;
  

    // getters and setters methods
 public int getRoomNumber()
 {
         return roomNumber;
}
 
 public double getRentalRate()
 {
     
 return rentalRate;
 }
 
 public void setRoomNumber()
 {
 //this.roomNumber = Integer.parseInt(JOptionPane.showInputDialog("Enter room number:"));

}
 
 public void setRentalRate()
 {
// this.rentalRate = rate; 
 }
 public String toString()
{
return getRoomNumber()+" "+getRentalRate();
}
}
